package com.fraud.exception;

/**
 * Custom checked exception thrown when input parameters, amounts, or data models
 * fail business validation checks.
 */
public class ValidationException extends Exception {

    private static final long serialVersionUID = 1L;

    public ValidationException(String message) {
        super(message);
    }

    public ValidationException(String message, Throwable cause) {
        super(message, cause);
    }
}
