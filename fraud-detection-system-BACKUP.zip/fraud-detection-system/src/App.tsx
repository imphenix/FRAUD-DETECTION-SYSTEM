import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldAlert, ShieldCheck, Activity, Users, AlertTriangle, FileText, 
  Settings, LogOut, ArrowUpRight, IndianRupee, Clock, MapPin, CheckCircle, 
  XCircle, Filter, Search, RefreshCw, Lock, Sparkles, HeartHandshake,
  TrendingUp, Compass, Shield, Flower2, Heart, Award, ChevronRight, UserPlus,
  UserCheck, CreditCard, Mail, KeyRound, Building, Check, Volume2, VolumeX,
  Bell, Play, Pause, Zap, CheckCheck, Trash2, ExternalLink, Smartphone, Landmark, Radio
} from 'lucide-react';

interface User {
  id: number;
  username: string;
  fullName: string;
  email: string;
  phone?: string;
  role: 'ADMIN' | 'CUSTOMER';
  accountNumber?: string;
  balance?: number;
  riskProfile?: string;
  department?: string;
  clearanceLevel?: number;
  createdAt?: string;
}

interface BankAccount {
  bankAccountId: number;
  customerId: number;
  bankName: string;
  maskedAccountNumber: string;
  accountNumber: string;
  balance: number;
  registeredMobile: string;
  status: 'CONNECTED' | 'ACTIVE' | 'FROZEN';
  createdAt: string;
  updatedAt: string;
}

interface CustomerNotification {
  id: number;
  userId: number;
  transactionId: number;
  referenceId: string;
  amount: number;
  title: string;
  message: string;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'APPROVED' | 'FLAGGED' | 'BLOCKED';
  triggeredRules: string[];
  reasons: string[];
  recommendedAction: string;
  read: boolean;
  createdAt: string;
}

interface Transaction {
  id: number;
  userId: number;
  referenceId: string;
  senderAccount: string;
  recipientAccount: string;
  merchant?: string;
  amount: number;
  transactionType: string;
  status: 'APPROVED' | 'FLAGGED' | 'BLOCKED';
  riskScore: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  location: string;
  createdAt: string;
  notes?: string;
  triggeredRules?: string[];
  reasons?: string[];
  riskAnalysis?: {
    riskScore: number;
    riskLevel: string;
    status: string;
    triggeredRules: string[];
    reasons: string[];
    flagged: boolean;
    blocked: boolean;
  };
}

interface FraudCase {
  id: number;
  caseNumber: string;
  transactionId: number;
  userId: number;
  assignedTo?: number | null;
  status: 'OPEN' | 'INVESTIGATING' | 'RESOLVED_FRAUD' | 'RESOLVED_LEGITIMATE';
  riskScore: number;
  notes: string;
  resolutionDetails?: string | null;
  createdAt: string;
}

interface FraudAlert {
  id: number;
  transactionId: number;
  userId?: number;
  ruleCode: string;
  severity: string;
  message: string;
  triggeredAt: string;
}

interface FraudRule {
  id: number;
  ruleCode: string;
  ruleName: string;
  description: string;
  weight: number;
  thresholdValue: number;
  active: boolean;
}

// Monetary parsing and formatting helpers supporting Indian Rupees (₹ INR)
export function parseMonetaryAmount(raw: any): number {
  if (typeof raw === 'number') return isNaN(raw) ? 0 : raw;
  if (!raw) return 0;
  const clean = String(raw).replace(/[^0-9.-]/g, '');
  const val = parseFloat(clean);
  return isNaN(val) ? 0 : val;
}

export function formatINR(val: number | string | bigint | undefined | null, includeDecimals = true): string {
  if (val === undefined || val === null || val === '') return '₹0.00';
  let str = String(val).trim().replace(/₹|\$|,/g, '');
  if (str === '' || isNaN(Number(str))) return '₹0.00';

  // Handle large numbers or scientific notation cleanly without losing digits
  if (str.includes('e') || str.includes('E')) {
    try {
      str = BigInt(Math.round(Number(str))).toString();
    } catch {
      str = String(Number(str).toFixed(0));
    }
  }

  let [integerPart, decimalPart] = str.split('.');
  let isNegative = integerPart.startsWith('-');
  if (isNegative) integerPart = integerPart.substring(1);

  // Indian formatting: last 3 digits, then pairs of 2 digits
  let lastThree = integerPart.slice(-3);
  let otherNumbers = integerPart.slice(0, -3);
  if (otherNumbers !== '') {
    lastThree = ',' + lastThree;
  }
  let formattedInteger = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree;

  let formatted = (isNegative ? '-' : '') + '₹' + formattedInteger;
  if (includeDecimals) {
    if (!decimalPart) {
      formatted += '.00';
    } else {
      formatted += '.' + decimalPart.padEnd(2, '0').slice(0, 2);
    }
  }
  return formatted;
}

// Aliases for complete backward compatibility
export const formatCurrency = formatINR;
export const formatUSD = formatINR;

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'bankfeed' | 'transactions' | 'submit' | 'cases' | 'rules' | 'profile' | 'users'>('dashboard');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [cases, setCases] = useState<FraudCase[]>([]);
  const [alerts, setAlerts] = useState<FraudAlert[]>([]);
  const [rules, setRules] = useState<FraudRule[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [dashboardMetrics, setDashboardMetrics] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Linked Demo Bank Account State
  const [bankAccount, setBankAccount] = useState<BankAccount | null>(null);

  // Customer Notifications & Notification Center
  const [notifications, setNotifications] = useState<CustomerNotification[]>([]);
  const [unreadNotifCount, setUnreadNotifCount] = useState<number>(0);
  const [showNotificationCenter, setShowNotificationCenter] = useState<boolean>(false);
  const [browserNotifsEnabled, setBrowserNotifsEnabled] = useState<boolean>(false);

  // Live Bank Feed & Simulator State
  const [isSimulatingFeed, setIsSimulatingFeed] = useState<boolean>(false);
  const [simulatingLoading, setSimulatingLoading] = useState<boolean>(false);
  const [lastFeedItem, setLastFeedItem] = useState<{
    scenario: any;
    transaction: Transaction;
    riskAnalysis: any;
    notification: CustomerNotification;
  } | null>(null);

  // Fraud Emergency Mode visual state driven strictly by the backend RiskAnalysis
  const [activeEmergencyAlert, setActiveEmergencyAlert] = useState<Transaction | null>(null);
  const [emergencyDismissed, setEmergencyDismissed] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(false);

  // Auth Mode: 'login' | 'register'
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSuccess, setAuthSuccess] = useState<string | null>(null);

  // Login Form states
  const [loginIdentifier, setLoginIdentifier] = useState('john_doe');
  const [loginPassword, setLoginPassword] = useState('password123');

  // Registration Form states
  const [regFullName, setRegFullName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regInitialBalance, setRegInitialBalance] = useState('450000.00');

  // New Transaction Form (Defaults to realistic Indian scenario)
  const [recipient, setRecipient] = useState('ACC-RECIPIENT-88');
  const [amount, setAmount] = useState('1500.00');
  const [txType, setTxType] = useState('PAYMENT');
  const [location, setLocation] = useState('New Delhi, India');
  const [submittingTx, setSubmittingTx] = useState(false);
  const [submissionFeedback, setSubmissionFeedback] = useState<Transaction | null>(null);

  useEffect(() => {
    fetchSession();
    // Check initial browser notification permission
    if ('Notification' in window && Notification.permission === 'granted') {
      setBrowserNotifsEnabled(true);
    }
  }, []);

  useEffect(() => {
    if (currentUser) {
      loadData();
    }
  }, [currentUser]);

  // Automatic Bank Transaction Simulator interval runner
  useEffect(() => {
    let interval: any = null;
    if (isSimulatingFeed && currentUser) {
      interval = setInterval(() => {
        triggerSimulatedTransaction();
      }, 7500); // Trigger a realistic transaction event every 7.5 seconds
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isSimulatingFeed, currentUser]);

  const fetchSession = async () => {
    try {
      const res = await fetch('/api/auth?action=me');
      const data = await res.json();
      if (data.success && data.data.authenticated && data.data.user) {
        setCurrentUser(data.data.user);
      } else {
        setCurrentUser(null);
      }
    } catch (e) {
      setCurrentUser(null);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (username = loginIdentifier, password = loginPassword) => {
    setAuthError(null);
    setAuthSuccess(null);
    try {
      const res = await fetch('/api/auth?action=login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (data.success) {
        setCurrentUser(data.data.user);
        setActiveTab('dashboard');
      } else {
        setAuthError(data.error || 'Authentication failed');
      }
    } catch (e: any) {
      setAuthError('Connection error: ' + e.message);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccess(null);

    if (regPassword !== regConfirmPassword) {
      setAuthError("Passwords do not match");
      return;
    }

    if (regPassword.length < 6) {
      setAuthError("Password must be at least 6 characters long");
      return;
    }

    try {
      const res = await fetch('/api/auth?action=register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: regFullName,
          username: regUsername,
          email: regEmail,
          phone: regPhone,
          password: regPassword,
          initialBalance: parseFloat(regInitialBalance) || 450000.00
        })
      });

      const data = await res.json();
      if (data.success) {
        setAuthSuccess("Registration successful! Logging you into your new account...");
        setCurrentUser(data.data.user);
        setActiveTab('dashboard');
        // Reset form
        setRegFullName('');
        setRegUsername('');
        setRegEmail('');
        setRegPhone('');
        setRegPassword('');
        setRegConfirmPassword('');
      } else {
        setAuthError(data.error || 'Registration failed');
      }
    } catch (e: any) {
      setAuthError('Network error: ' + e.message);
    }
  };

  const playWarningChime = (level: string) => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = level === 'CRITICAL' ? 'sawtooth' : 'sine';
      osc.frequency.setValueAtTime(level === 'CRITICAL' ? 880 : 540, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(level === 'CRITICAL' ? 440 : 880, ctx.currentTime + 0.25);
      gain.gain.setValueAtTime(0.06, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {
      // Audio playback silently ignored
    }
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth?action=logout', { method: 'POST' });
    } catch (e) {
      console.error(e);
    }
    setCurrentUser(null);
    setTransactions([]);
    setCases([]);
    setAlerts([]);
    setBankAccount(null);
    setNotifications([]);
    setUnreadNotifCount(0);
    setIsSimulatingFeed(false);
    setDashboardMetrics(null);
    setSubmissionFeedback(null);
    setActiveEmergencyAlert(null);
    setEmergencyDismissed(false);
    setActiveTab('dashboard');
  };

  const loadData = async () => {
    try {
      const fetches = [
        fetch('/api/transactions'),
        fetch('/api/cases'),
        fetch('/api/alerts'),
        fetch('/api/dashboard'),
        fetch('/api/rules'),
        fetch('/api/bank-account'),
        fetch('/api/notifications')
      ];

      if (currentUser?.role === 'ADMIN') {
        fetches.push(fetch('/api/auth?action=users'));
      }

      const results = await Promise.all(fetches);
      const [txData, caseData, alertData, dashData, ruleData, bankData, notifData, usersData] = await Promise.all(
        results.map(r => r.json())
      );

      if (txData.success) setTransactions(txData.data);
      if (caseData.success) setCases(caseData.data);
      if (alertData.success) setAlerts(alertData.data);
      if (dashData.success) setDashboardMetrics(dashData.data);
      if (ruleData.success) setRules(ruleData.data);
      if (bankData && bankData.success) setBankAccount(bankData.data);
      if (notifData && notifData.success) {
        setNotifications(notifData.data.notifications || []);
        setUnreadNotifCount(notifData.data.unreadCount || 0);
      }
      if (usersData && usersData.success) setAllUsers(usersData.data);
    } catch (e) {
      console.error('Failed to load system data', e);
    }
  };

  // Bank Simulator Trigger
  const triggerSimulatedTransaction = async (scenarioKey?: string) => {
    setSimulatingLoading(true);
    try {
      const res = await fetch('/api/bank/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenarioKey })
      });
      const data = await res.json();
      if (data.success) {
        const item = data.data;
        setLastFeedItem(item);

        // Check if risky according to real backend RiskAnalysis
        const txResult: Transaction = item.transaction;
        const isRisky = txResult.status === 'FLAGGED' || 
                        txResult.status === 'BLOCKED' || 
                        (txResult.riskScore !== undefined && txResult.riskScore >= 40) ||
                        (txResult.riskLevel && txResult.riskLevel !== 'LOW') ||
                        (txResult.riskAnalysis && (txResult.riskAnalysis.flagged || txResult.riskAnalysis.blocked));

        if (isRisky) {
          setActiveEmergencyAlert(txResult);
          setEmergencyDismissed(false);
          playWarningChime(txResult.riskLevel);
        }

        // Trigger browser notification if enabled
        if (browserNotifsEnabled && 'Notification' in window && Notification.permission === 'granted') {
          try {
            new Notification(item.notification.title, {
              body: item.notification.message,
              icon: '/favicon.ico'
            });
          } catch {
            // ignore
          }
        }

        // Refresh data
        await loadData();
        await fetchSession();
      }
    } catch (e) {
      console.error('Simulation error:', e);
    } finally {
      setSimulatingLoading(false);
    }
  };

  const handleFundDemoAccount = async (amount = 100000) => {
    try {
      const res = await fetch('/api/bank-account', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'fund', amount })
      });
      const data = await res.json();
      if (data.success) {
        setBankAccount(data.data);
        await fetchSession();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleResetDemoAccount = async () => {
    try {
      const res = await fetch('/api/bank-account', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reset' })
      });
      const data = await res.json();
      if (data.success) {
        setBankAccount(data.data);
        await fetchSession();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleMarkNotificationRead = async (notifId: number) => {
    try {
      await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mark-read', notificationId: notifId })
      });
      setNotifications(prev => prev.map(n => n.id === notifId ? { ...n, read: true } : n));
      setUnreadNotifCount(prev => Math.max(0, prev - 1));
    } catch (e) {
      console.error(e);
    }
  };

  const handleMarkAllNotificationsRead = async () => {
    try {
      await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mark-all-read' })
      });
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnreadNotifCount(0);
    } catch (e) {
      console.error(e);
    }
  };

  const handleClearNotifications = async () => {
    try {
      await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'clear' })
      });
      setNotifications([]);
      setUnreadNotifCount(0);
    } catch (e) {
      console.error(e);
    }
  };

  const toggleBrowserNotifications = async () => {
    if (!('Notification' in window)) {
      alert("Browser Notifications are not supported in this browser environment.");
      return;
    }
    if (Notification.permission === 'granted') {
      setBrowserNotifsEnabled(!browserNotifsEnabled);
      return;
    }
    const perm = await Notification.requestPermission();
    if (perm === 'granted') {
      setBrowserNotifsEnabled(true);
      new Notification("🔔 FraudGuard Alerts Active", {
        body: "Real-time banking notifications and fraud alerts enabled."
      });
    } else {
      setBrowserNotifsEnabled(false);
      alert("Desktop notification permission was denied or dismissed.");
    }
  };

  const handleTransactionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingTx(true);
    setSubmissionFeedback(null);

    try {
      const parsedAmount = parseMonetaryAmount(amount);
      if (isNaN(parsedAmount) || parsedAmount <= 0) {
        alert("Please enter a valid positive amount");
        setSubmittingTx(false);
        return;
      }

      const res = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipientAccount: recipient,
          amount: parsedAmount,
          transactionType: txType,
          location
        })
      });

      const data = await res.json();
      if (data.success) {
        const txResult: Transaction = data.data;
        setSubmissionFeedback(txResult);

        // Drive emergency visual state from the real backend RiskAnalysis
        const isRisky = txResult.status === 'FLAGGED' || 
                        txResult.status === 'BLOCKED' || 
                        (txResult.riskScore !== undefined && txResult.riskScore >= 40) ||
                        (txResult.riskLevel && txResult.riskLevel !== 'LOW') ||
                        (txResult.riskAnalysis && (txResult.riskAnalysis.flagged || txResult.riskAnalysis.blocked));

        if (isRisky) {
          setActiveEmergencyAlert(txResult);
          setEmergencyDismissed(false);
          playWarningChime(txResult.riskLevel);
        } else {
          // If approved, keep normal elegant blush pink aesthetic
          setActiveEmergencyAlert(null);
          setEmergencyDismissed(false);
        }

        // Refresh customer session & ledger data
        await fetchSession();
        await loadData();
      } else {
        alert(data.error || 'Transaction failed');
      }
    } catch (e: any) {
      alert('Transaction error: ' + e.message);
    } finally {
      setSubmittingTx(false);
    }
  };

  const handleResolveCase = async (caseId: number, finalStatus: string) => {
    const details = prompt('Enter investigation resolution details:');
    if (!details) return;

    try {
      const res = await fetch('/api/cases?action=resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ caseId, finalStatus, resolutionDetails: details })
      });
      const data = await res.json();
      if (data.success) {
        loadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const toggleRule = async (rule: FraudRule) => {
    try {
      await fetch('/api/rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: rule.id, active: !rule.active })
      });
      loadData();
    } catch (e) {
      console.error(e);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/80 shadow-xs">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> Approved
          </span>
        );
      case 'FLAGGED':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-50/90 text-rose-700 border border-rose-200/80 shadow-xs">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-500" /> Flagged
          </span>
        );
      case 'BLOCKED':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-red-50 text-red-700 border border-red-200 shadow-xs">
            <XCircle className="w-3.5 h-3.5 text-red-600" /> Blocked
          </span>
        );
      default:
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-pink-50 text-slate-700 border border-pink-200">
            {status}
          </span>
        );
    }
  };

  const getRiskBadge = (level: string, score: number) => {
    const config = 
      level === 'CRITICAL' ? 'bg-red-50 text-red-700 border-red-200' :
      level === 'HIGH' ? 'bg-rose-50 text-rose-700 border-rose-200' :
      level === 'MEDIUM' ? 'bg-purple-50 text-purple-700 border-purple-200' :
      'bg-emerald-50 text-emerald-700 border-emerald-200';
    return (
      <span className={`px-2.5 py-0.5 rounded-full font-mono text-xs font-bold border ${config}`}>
        {level} ({score})
      </span>
    );
  };

  // ===================== AUTHENTICATION SCREEN =====================
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-100/70 via-rose-50 to-purple-100/60 flex items-center justify-center p-4 selection:bg-pink-200 relative overflow-hidden">
        {/* Subtle decorative floating botanical elements */}
        <div className="absolute top-10 left-12 text-pink-300/40 pointer-events-none animate-float-slow">
          <Flower2 className="w-16 h-16" />
        </div>
        <div className="absolute bottom-12 right-16 text-purple-300/40 pointer-events-none animate-float-slow" style={{ animationDelay: '2s' }}>
          <Sparkles className="w-14 h-14" />
        </div>
        <div className="absolute top-1/3 right-10 text-rose-300/30 pointer-events-none animate-float-slow" style={{ animationDelay: '4s' }}>
          <Heart className="w-10 h-10" />
        </div>

        <div className="max-w-lg w-full bg-white/95 backdrop-blur-md border border-pink-200/80 rounded-3xl p-7 sm:p-9 shadow-xl shadow-pink-200/40 relative z-10 animate-pulse-glow">
          {/* Header */}
          <div className="flex items-center gap-3.5 mb-6">
            <div className="w-12 h-12 bg-gradient-to-tr from-pink-500 via-rose-400 to-purple-400 rounded-2xl flex items-center justify-center text-white shadow-md shadow-pink-200">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-xl font-bold text-slate-800 tracking-tight">FraudGuard System</h2>
                <Sparkles className="w-4 h-4 text-pink-400" />
              </div>
              <p className="text-xs text-slate-500 font-medium">Enterprise Multi-User Fraud Detection Platform (₹ INR)</p>
            </div>
          </div>

          {/* Tab Selector: Sign In vs Create Account */}
          <div className="flex bg-pink-50/70 p-1 rounded-2xl border border-pink-100 mb-6">
            <button
              onClick={() => { setAuthMode('login'); setAuthError(null); }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                authMode === 'login' 
                  ? 'bg-white text-pink-700 shadow-xs' 
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <KeyRound className="w-3.5 h-3.5" />
              Sign In
            </button>
            <button
              onClick={() => { setAuthMode('register'); setAuthError(null); }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                authMode === 'register' 
                  ? 'bg-white text-pink-700 shadow-xs' 
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              Create Account
            </button>
          </div>

          {/* Feedback messages */}
          {authError && (
            <div className="mb-4 p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{authError}</span>
            </div>
          )}
          {authSuccess && (
            <div className="mb-4 p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-semibold flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{authSuccess}</span>
            </div>
          )}

          {/* Mode 1: Login Form */}
          {authMode === 'login' ? (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Username or Email</label>
                <input 
                  type="text" 
                  value={loginIdentifier} 
                  onChange={e => setLoginIdentifier(e.target.value)}
                  placeholder="e.g. john_doe or john@example.com"
                  className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3.5 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Password</label>
                <input 
                  type="password" 
                  value={loginPassword} 
                  onChange={e => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3.5 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                />
              </div>

              <div className="flex gap-2.5 pt-2">
                <button 
                  onClick={() => handleLogin()}
                  className="flex-1 bg-gradient-to-r from-pink-500 via-rose-500 to-purple-500 hover:opacity-95 text-white font-semibold py-2.5 rounded-xl text-sm transition shadow-md shadow-pink-200 cursor-pointer"
                >
                  Sign In
                </button>
              </div>

              <div className="pt-3 border-t border-pink-100">
                <span className="text-[11px] font-semibold text-slate-500 block mb-2 text-center">Quick Demo Accounts:</span>
                <div className="grid grid-cols-2 gap-2">
                  <button 
                    onClick={() => { setLoginIdentifier('john_doe'); setLoginPassword('password123'); handleLogin('john_doe', 'password123'); }}
                    className="p-2 bg-pink-50/60 hover:bg-pink-100/70 border border-pink-200/80 rounded-xl text-left transition cursor-pointer"
                  >
                    <div className="text-xs font-bold text-pink-700">Johnathan Doe</div>
                    <div className="text-[10px] text-slate-500">Customer (₹50,00,000)</div>
                  </button>
                  <button 
                    onClick={() => { setLoginIdentifier('admin'); setLoginPassword('admin123'); handleLogin('admin', 'admin123'); }}
                    className="p-2 bg-purple-50/60 hover:bg-purple-100/70 border border-purple-200/80 rounded-xl text-left transition cursor-pointer"
                  >
                    <div className="text-xs font-bold text-purple-700">Security Lead</div>
                    <div className="text-[10px] text-slate-500">System Administrator</div>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Mode 2: Register Form */
            <form onSubmit={handleRegister} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
                  <input 
                    type="text" 
                    value={regFullName} 
                    onChange={e => setRegFullName(e.target.value)}
                    placeholder="e.g. Priya Sharma"
                    className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Username</label>
                  <input 
                    type="text" 
                    value={regUsername} 
                    onChange={e => setRegUsername(e.target.value)}
                    placeholder="e.g. priya_sharma"
                    className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
                  <input 
                    type="email" 
                    value={regEmail} 
                    onChange={e => setRegEmail(e.target.value)}
                    placeholder="priya@example.in"
                    className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number (Optional)</label>
                  <input 
                    type="text" 
                    value={regPhone} 
                    onChange={e => setRegPhone(e.target.value)}
                    placeholder="+91-98765-43210"
                    className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Password</label>
                  <input 
                    type="password" 
                    value={regPassword} 
                    onChange={e => setRegPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Confirm Password</label>
                  <input 
                    type="password" 
                    value={regConfirmPassword} 
                    onChange={e => setRegConfirmPassword(e.target.value)}
                    placeholder="Repeat password"
                    className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Initial Demo Balance (₹ INR)</label>
                <input 
                  type="number" 
                  step="1000"
                  value={regInitialBalance} 
                  onChange={e => setRegInitialBalance(e.target.value)}
                  placeholder="500000.00"
                  className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3.5 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                  required
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  A unique bank account number (e.g. <span className="font-mono text-pink-600">ACC-XXXXXXXX</span>) will be automatically generated upon registration.
                </span>
              </div>

              <button 
                type="submit"
                className="w-full mt-3 bg-gradient-to-r from-pink-500 via-rose-500 to-purple-500 hover:opacity-95 text-white font-semibold py-2.5 rounded-xl text-xs transition shadow-md shadow-pink-200 cursor-pointer"
              >
                Register & Open Account
              </button>
            </form>
          )}
        </div>
      </div>
    );
  }

  // ===================== AUTHENTICATED USER PORTAL =====================
  const isEmergency = Boolean(activeEmergencyAlert && !emergencyDismissed);
  const emergencyLevel = activeEmergencyAlert?.riskLevel || 'LOW';

  return (
    <div className={`min-h-screen text-slate-800 flex flex-col font-sans selection:bg-pink-200 relative overflow-x-hidden transition-colors duration-700 ${
      isEmergency
        ? emergencyLevel === 'CRITICAL'
          ? 'bg-gradient-to-br from-red-100/90 via-rose-100/60 to-red-50/70'
          : emergencyLevel === 'HIGH'
          ? 'bg-gradient-to-br from-rose-100/85 via-pink-100/50 to-red-50/60'
          : 'bg-gradient-to-br from-pink-100/80 via-rose-100/40 to-purple-50/60'
        : 'bg-gradient-to-br from-pink-50/70 via-rose-50/40 to-purple-50/60'
    }`}>
      {/* Viewport Emergency Alert Border & Glow Pulse Effect */}
      {isEmergency && (
        <div
          aria-hidden="true"
          className={`fixed inset-0 pointer-events-none z-50 transition-all duration-700 motion-reduce:animate-none ${
            emergencyLevel === 'CRITICAL'
              ? 'animate-emergency-critical'
              : 'animate-emergency-border'
          }`}
        />
      )}

      {/* TOP EMERGENCY ALERT BANNER */}
      {isEmergency && activeEmergencyAlert && (
        <aside 
          role="alert"
          aria-live="assertive"
          className={`sticky top-0 z-50 transition-all duration-300 shadow-xl animate-emergency-banner ${
            emergencyLevel === 'CRITICAL'
              ? 'bg-gradient-to-r from-red-700 via-rose-800 to-red-900 text-white border-b-2 border-red-500'
              : emergencyLevel === 'HIGH'
              ? 'bg-gradient-to-r from-rose-700 via-red-600 to-rose-800 text-white border-b-2 border-rose-400'
              : 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-700 text-white border-b-2 border-rose-300'
          }`}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
            <div className="flex items-center gap-3.5">
              <div className="p-2.5 rounded-2xl bg-white/20 backdrop-blur-xs motion-reduce:animate-none animate-emergency-badge shrink-0">
                {emergencyLevel === 'CRITICAL' ? (
                  <XCircle className="w-6 h-6 text-white" />
                ) : (
                  <AlertTriangle className="w-6 h-6 text-white" />
                )}
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-extrabold text-sm sm:text-base tracking-wide uppercase flex items-center gap-2">
                    {emergencyLevel === 'CRITICAL'
                      ? '🚨 CRITICAL FRAUD ALERT — TRANSACTION BLOCKED'
                      : emergencyLevel === 'HIGH'
                      ? '🚨 HIGH FRAUD RISK'
                      : '⚠️ FRAUD RISK DETECTED'}
                  </span>
                  <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-white/20 text-white border border-white/30">
                    STATUS: {activeEmergencyAlert.status}
                  </span>
                  <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-white/20 text-white border border-white/30">
                    RISK SCORE: {activeEmergencyAlert.riskScore} / 100
                  </span>
                  <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-white/20 text-white border border-white/30">
                    LEVEL: {activeEmergencyAlert.riskLevel}
                  </span>
                </div>
                <p className="text-xs text-white/90 font-medium mt-0.5">
                  {emergencyLevel === 'CRITICAL'
                    ? 'Immediate investigation required. High-severity threat halted by the FraudDetectionEngine.'
                    : emergencyLevel === 'HIGH'
                    ? 'Suspicious transaction detected by the FraudDetectionEngine. High risk severity.'
                    : 'Transaction requires attention. Suspicious signals detected by the FraudDetectionEngine.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5 self-end md:self-center shrink-0">
              <div className="text-right hidden xl:block text-xs font-mono pr-2 border-r border-white/30">
                <div className="text-white/80 text-[10px]">Suspicious Amount</div>
                <div className="font-bold text-white text-sm">{formatINR(activeEmergencyAlert.amount)}</div>
              </div>
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className="p-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs transition border border-white/30 cursor-pointer flex items-center gap-1"
                title={soundEnabled ? 'Mute alert chime' : 'Enable subtle audio chime'}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-white/70" />}
                <span className="text-[10px] hidden sm:inline">{soundEnabled ? 'Chime ON' : 'Chime Muted'}</span>
              </button>
              <button
                onClick={() => setEmergencyDismissed(true)}
                className="px-3.5 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-bold transition border border-white/40 cursor-pointer shadow-xs"
              >
                Dismiss Alert
              </button>
            </div>
          </div>
        </aside>
      )}

      {/* Decorative botanical subtle accents */}
      <div className="absolute top-16 right-6 text-pink-300/20 pointer-events-none animate-float-slow -z-10">
        <Flower2 className="w-28 h-28" />
      </div>
      <div className="absolute bottom-20 left-4 text-purple-300/20 pointer-events-none animate-float-slow -z-10" style={{ animationDelay: '3s' }}>
        <Sparkles className="w-24 h-24" />
      </div>

      {/* Top Navbar */}
      <header className="border-b border-pink-200/80 bg-white/80 backdrop-blur-md sticky top-0 z-40 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-tr from-pink-500 via-rose-400 to-purple-400 rounded-2xl flex items-center justify-center text-white shadow-sm shadow-pink-200">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 tracking-tight text-base sm:text-lg flex items-center gap-1.5">
                  FraudGuard System
                  <Sparkles className="w-4 h-4 text-pink-400 hidden sm:inline" />
                </span>
                <span className="text-[10px] uppercase font-bold px-2.5 py-0.5 rounded-full bg-pink-100 text-pink-700 border border-pink-200/80 shadow-xs">
                  {currentUser.role === 'ADMIN' ? 'ADMIN CONSOLE (₹ INR)' : 'CUSTOMER PORTAL (₹ INR)'}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <div className="text-xs font-bold text-slate-800">{currentUser.fullName}</div>
              <div className="text-[11px] text-pink-700 font-semibold flex items-center justify-end gap-1">
                {currentUser.role === 'ADMIN' ? (
                  <span className="text-purple-700 font-bold">Security Compliance Lead</span>
                ) : (
                  <span>
                    Acct: {bankAccount?.maskedAccountNumber || currentUser.accountNumber} • {formatINR(bankAccount?.balance ?? currentUser.balance)}
                  </span>
                )}
              </div>
            </div>

            {/* Notification Bell with live unread badge */}
            <div className="relative">
              <button 
                onClick={() => setShowNotificationCenter(!showNotificationCenter)}
                className={`relative p-2.5 rounded-2xl transition border cursor-pointer shadow-xs ${
                  unreadNotifCount > 0 
                    ? 'bg-rose-50 text-rose-700 border-rose-300 hover:bg-rose-100/70' 
                    : 'bg-white hover:bg-pink-50 text-slate-600 border-pink-200/80'
                }`}
                title="Customer Notification Center"
                aria-label="Notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadNotifCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-gradient-to-r from-red-500 to-rose-600 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center shadow-xs animate-pulse">
                    {unreadNotifCount > 9 ? '9+' : unreadNotifCount}
                  </span>
                )}
              </button>

              {/* Notification Center Popover */}
              {showNotificationCenter && (
                <>
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setShowNotificationCenter(false)} 
                  />
                  <div className="absolute right-0 mt-3 w-80 sm:w-96 bg-white/98 backdrop-blur-md rounded-3xl border border-pink-200 shadow-2xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
                    <div className="p-4 border-b border-pink-100 bg-gradient-to-r from-pink-50/80 to-purple-50/60 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-xl bg-pink-100 text-pink-700 flex items-center justify-center font-bold">
                          <Bell className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-slate-800">Notifications</h4>
                          <span className="text-[10px] text-pink-700 font-semibold">{unreadNotifCount} unread alert{unreadNotifCount === 1 ? '' : 's'}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={handleMarkAllNotificationsRead}
                          className="px-2 py-1 text-[10px] font-bold text-slate-600 hover:text-pink-700 hover:bg-pink-100/60 rounded-lg transition cursor-pointer"
                          title="Mark all notifications as read"
                        >
                          Mark all read
                        </button>
                        <button
                          onClick={handleClearNotifications}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded-lg transition cursor-pointer"
                          title="Clear all"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Browser Notifications Permission Bar */}
                    <div className="px-4 py-2 bg-pink-50/40 border-b border-pink-100 flex items-center justify-between text-[11px]">
                      <span className="text-slate-600 font-medium flex items-center gap-1.5">
                        <Smartphone className="w-3.5 h-3.5 text-pink-600" />
                        Desktop Alerts:
                      </span>
                      <button
                        onClick={toggleBrowserNotifications}
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold transition cursor-pointer ${
                          browserNotifsEnabled 
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                            : 'bg-white text-slate-600 hover:bg-pink-100 border border-pink-200'
                        }`}
                      >
                        {browserNotifsEnabled ? '● Enabled' : 'Enable'}
                      </button>
                    </div>

                    {/* Notification List */}
                    <div className="max-h-96 overflow-y-auto divide-y divide-pink-100/80">
                      {notifications.length === 0 ? (
                        <div className="p-8 text-center text-slate-400 text-xs">
                          <CheckCheck className="w-8 h-8 text-pink-300 mx-auto mb-2 opacity-60" />
                          No banking notifications recorded.
                        </div>
                      ) : (
                        notifications.map(n => (
                          <div 
                            key={n.id} 
                            onClick={() => handleMarkNotificationRead(n.id)}
                            className={`p-3.5 transition cursor-pointer hover:bg-pink-50/40 ${
                              !n.read ? 'bg-pink-50/30' : ''
                            }`}
                          >
                            <div className="flex items-start gap-2.5">
                              <div className="mt-0.5 shrink-0">
                                {n.status === 'BLOCKED' ? (
                                  <div className="w-6 h-6 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
                                    <XCircle className="w-3.5 h-3.5" />
                                  </div>
                                ) : n.status === 'FLAGGED' ? (
                                  <div className="w-6 h-6 rounded-lg bg-rose-100 text-rose-600 flex items-center justify-center">
                                    <AlertTriangle className="w-3.5 h-3.5" />
                                  </div>
                                ) : (
                                  <div className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
                                    <CheckCircle className="w-3.5 h-3.5" />
                                  </div>
                                )}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-1 mb-0.5">
                                  <span className={`text-xs font-bold truncate ${
                                    n.status === 'BLOCKED' ? 'text-red-700' : n.status === 'FLAGGED' ? 'text-rose-700' : 'text-slate-800'
                                  }`}>
                                    {n.title}
                                  </span>
                                  <span className="text-[10px] text-slate-400 font-mono shrink-0">{n.createdAt.substring(11, 16)}</span>
                                </div>
                                <p className="text-xs text-slate-700 leading-snug">{n.message}</p>
                                <div className="mt-1 flex items-center gap-2 text-[10px] font-mono text-slate-500">
                                  <span className="font-bold text-slate-800">{formatINR(n.amount)}</span>
                                  <span>&bull;</span>
                                  <span>{n.referenceId}</span>
                                </div>
                                {n.recommendedAction && (
                                  <div className="mt-1 text-[10px] font-semibold text-pink-800/90 bg-pink-100/60 px-2 py-0.5 rounded-md">
                                    {n.recommendedAction}
                                  </div>
                                )}
                              </div>
                              {!n.read && (
                                <span className="w-2 h-2 rounded-full bg-pink-500 shrink-0 mt-1" />
                              )}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>

            <button 
              onClick={handleLogout}
              className="p-2.5 hover:bg-pink-50 text-slate-500 hover:text-pink-600 rounded-2xl transition border border-pink-100 hover:border-pink-200 cursor-pointer shadow-xs"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 w-full flex-1 flex flex-col gap-6">
        {/* Navigation Tabs */}
        <div className="flex border-b border-pink-200/80 gap-1.5 pb-px overflow-x-auto">
          {[
            { id: 'dashboard', label: currentUser.role === 'ADMIN' ? 'Executive Dashboard' : 'My Dashboard', icon: Activity },
            { id: 'bankfeed', label: 'Live Bank Activity & Simulator', icon: Landmark },
            { id: 'transactions', label: currentUser.role === 'ADMIN' ? 'All Transactions' : 'My Ledger', icon: IndianRupee },
            { id: 'submit', label: 'Submit Transaction', icon: ArrowUpRight },
            { id: 'cases', label: currentUser.role === 'ADMIN' ? 'Fraud Investigations' : 'My Alerts & Cases', icon: FileText },
            { id: 'profile', label: 'Account Profile', icon: UserCheck },
            ...(currentUser.role === 'ADMIN' ? [
              { id: 'users', label: 'User Directory', icon: Users },
              { id: 'rules', label: 'Fraud Rule Config', icon: Settings }
            ] : [])
          ].map(tab => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold border-b-2 transition whitespace-nowrap cursor-pointer rounded-t-2xl ${
                  active 
                    ? 'border-pink-500 text-pink-700 bg-white/95 shadow-xs' 
                    : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-pink-50/50'
                }`}
              >
                <Icon className={`w-4 h-4 ${active ? 'text-pink-600' : 'text-slate-400'}`} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab 1: Dashboard (Dynamic & User-Specific in INR) */}
        {activeTab === 'dashboard' && dashboardMetrics && (
          <div className="space-y-6">
            {/* Linked Demo Bank Account Quick Banner for Customer */}
            {currentUser.role === 'CUSTOMER' && (
              <div className="bg-gradient-to-r from-pink-500/10 via-rose-500/5 to-purple-500/10 border border-pink-200/90 rounded-3xl p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-500 via-rose-500 to-purple-500 text-white flex items-center justify-center font-bold shadow-sm shadow-pink-200 shrink-0">
                    <Landmark className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-sm text-slate-900">{bankAccount?.bankName || 'FraudGuard Demo Bank'}</span>
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                        ● Connected
                      </span>
                      <span className="font-mono text-xs text-slate-500 font-bold bg-white/80 px-2 py-0.5 rounded-lg border border-pink-100">
                        Acct: {bankAccount?.maskedAccountNumber || 'XXXX XXXX 4521'}
                      </span>
                    </div>
                    <div className="text-xs text-slate-600 mt-1 flex items-baseline gap-2">
                      <span>Available Demo Balance:</span>
                      <span className="font-mono font-black text-emerald-600 text-base">
                        {formatINR(bankAccount?.balance ?? currentUser.balance)}
                      </span>
                      <span className="text-[10px] text-slate-400">({currentUser.fullName})</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap self-end md:self-center shrink-0">
                  <button
                    onClick={() => triggerSimulatedTransaction()}
                    disabled={simulatingLoading}
                    className="px-3.5 py-2 bg-pink-100/90 hover:bg-pink-200/90 text-pink-800 text-xs font-bold rounded-xl transition border border-pink-200 cursor-pointer shadow-xs flex items-center gap-1.5"
                  >
                    <Zap className="w-3.5 h-3.5 text-pink-600" />
                    Simulate Next Event
                  </button>
                  <button
                    onClick={() => setActiveTab('bankfeed')}
                    className="px-4 py-2 bg-gradient-to-r from-pink-500 via-rose-500 to-purple-500 hover:opacity-95 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer flex items-center gap-1.5"
                  >
                    <span>Open Bank Feed & Simulator</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Top Stat Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white/95 border border-pink-200/70 rounded-3xl p-5 shadow-sm shadow-pink-100/50 hover:shadow-md hover:-translate-y-0.5 transition duration-200 relative overflow-hidden">
                <div className="absolute top-2 right-2 text-pink-200/30 pointer-events-none">
                  <Flower2 className="w-12 h-12" />
                </div>
                <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                  <span>{currentUser.role === 'ADMIN' ? 'Total Transactions' : 'My Transactions'}</span>
                  <div className="w-8 h-8 rounded-xl bg-pink-50 flex items-center justify-center text-pink-600 border border-pink-100">
                    <Activity className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-slate-900 mt-2">{dashboardMetrics.totalTransactions}</div>
                <div className="text-emerald-600 text-[11px] font-semibold mt-1.5 flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" /> Fully Audited via ACID
                </div>
              </div>

              <div className="bg-white/95 border border-pink-200/70 rounded-3xl p-5 shadow-sm shadow-pink-100/50 hover:shadow-md hover:-translate-y-0.5 transition duration-200 relative overflow-hidden">
                <div className="absolute top-2 right-2 text-rose-200/30 pointer-events-none">
                  <Sparkles className="w-12 h-12" />
                </div>
                <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                  <span>Fraud Detection Rate</span>
                  <div className="w-8 h-8 rounded-xl bg-rose-50 flex items-center justify-center text-rose-500 border border-rose-100">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-rose-600 mt-2">{dashboardMetrics.fraudDetectionRate}%</div>
                <div className="text-slate-500 text-[11px] mt-1.5 font-medium">Multi-signal rule engine</div>
              </div>

              <div className="bg-white/95 border border-pink-200/70 rounded-3xl p-5 shadow-sm shadow-pink-100/50 hover:shadow-md hover:-translate-y-0.5 transition duration-200 relative overflow-hidden">
                <div className="absolute top-2 right-2 text-purple-200/30 pointer-events-none">
                  <Heart className="w-12 h-12" />
                </div>
                <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                  <span>{currentUser.role === 'ADMIN' ? 'Active Investigation Cases' : 'Cases on My Account'}</span>
                  <div className="w-8 h-8 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600 border border-purple-100">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-purple-700 mt-2">{dashboardMetrics.openCasesCount}</div>
                <div className="text-rose-500 text-[11px] mt-1.5 font-medium">
                  {currentUser.role === 'ADMIN' ? 'Requires compliance review' : 'Under compliance audit'}
                </div>
              </div>

              <div className="bg-white/95 border border-pink-200/70 rounded-3xl p-5 shadow-sm shadow-pink-100/50 hover:shadow-md hover:-translate-y-0.5 transition duration-200 relative overflow-hidden">
                <div className="absolute top-2 right-2 text-pink-200/30 pointer-events-none">
                  <Award className="w-12 h-12" />
                </div>
                <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                  <span>{currentUser.role === 'ADMIN' ? 'Total Volume Monitored' : 'Available Balance'}</span>
                  <div className="w-8 h-8 rounded-xl bg-pink-50 flex items-center justify-center text-pink-600 border border-pink-100">
                    <IndianRupee className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-slate-900 mt-2">
                  {formatINR(currentUser.role === 'ADMIN' ? dashboardMetrics.totalAmountProcessed : currentUser.balance)}
                </div>
                <div className="text-slate-500 text-[11px] mt-1.5 font-medium">
                  {currentUser.role === 'ADMIN' ? 'Real-time Indian banking flow' : `Account: ${currentUser.accountNumber}`}
                </div>
              </div>
            </div>

            {/* Distribution Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white/95 border border-pink-200/70 rounded-3xl p-6 shadow-sm shadow-pink-100/50">
                <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-pink-600" />
                  Transaction Status Breakdown
                </h3>
                <div className="space-y-3.5">
                  {Object.entries(dashboardMetrics.statusDistribution || {}).map(([st, count]: any) => (
                    <div key={st} className="flex justify-between items-center text-sm">
                      <span className="text-slate-600 font-semibold text-xs sm:text-sm">{st}</span>
                      <div className="flex items-center gap-3">
                        <div className="w-36 bg-pink-50 rounded-full h-2.5 overflow-hidden border border-pink-100">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              st === 'APPROVED' ? 'bg-emerald-400' : st === 'FLAGGED' ? 'bg-pink-400' : 'bg-rose-500'
                            }`}
                            style={{ width: `${Math.min(100, (count / Math.max(1, dashboardMetrics.totalTransactions)) * 100)}%` }}
                          />
                        </div>
                        <span className="font-mono text-xs font-bold text-slate-700 w-6 text-right">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white/95 border border-pink-200/70 rounded-3xl p-6 shadow-sm shadow-pink-100/50">
                <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-purple-600" />
                  Risk Level Breakdown
                </h3>
                <div className="space-y-3.5">
                  {Object.entries(dashboardMetrics.riskDistribution || {}).map(([lvl, count]: any) => (
                    <div key={lvl} className="flex justify-between items-center text-sm">
                      <span className="text-slate-600 font-semibold text-xs sm:text-sm">{lvl}</span>
                      <div className="flex items-center gap-3">
                        <div className="w-36 bg-pink-50 rounded-full h-2.5 overflow-hidden border border-pink-100">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              lvl === 'LOW' ? 'bg-emerald-400' : lvl === 'MEDIUM' ? 'bg-purple-400' : lvl === 'HIGH' ? 'bg-pink-500' : 'bg-rose-600'
                            }`}
                            style={{ width: `${Math.min(100, (count / Math.max(1, dashboardMetrics.totalTransactions)) * 100)}%` }}
                          />
                        </div>
                        <span className="font-mono text-xs font-bold text-slate-700 w-6 text-right">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Live Fraud Alerts Feed */}
            <div className="bg-white/95 border border-pink-200/70 rounded-3xl p-6 shadow-sm shadow-pink-100/50">
              <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-500" />
                {currentUser.role === 'ADMIN' ? 'Live System Fraud Alerts Stream' : 'Security Alerts for My Account'}
              </h3>
              {alerts.length === 0 ? (
                <div className="text-center py-6 text-xs text-slate-400 font-medium">
                  No fraud alerts recorded for this account.
                </div>
              ) : (
                <div className="divide-y divide-pink-100/80">
                  {alerts.slice(0, 5).map(alert => (
                    <div key={alert.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-1.5 hover:bg-pink-50/20 px-2 rounded-xl transition">
                      <div>
                        <span className="font-mono font-bold text-pink-700 mr-2 bg-pink-50 px-2.5 py-0.5 rounded-full border border-pink-200/80 shadow-xs">
                          {alert.ruleCode}
                        </span>
                        <span className="text-slate-700 font-semibold">{alert.message}</span>
                      </div>
                      <span className="text-slate-400 font-mono text-[11px] whitespace-nowrap">{alert.triggeredAt}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab: Live Bank Activity & Demo Account Simulator */}
        {activeTab === 'bankfeed' && (
          <div className="space-y-6">
            {/* 1. LINKED DEMO BANK ACCOUNT HERO CARD */}
            <div className="bg-gradient-to-br from-white via-pink-50/50 to-purple-50/50 border border-pink-200/90 rounded-3xl p-6 sm:p-7 shadow-sm shadow-pink-100/60 relative overflow-hidden">
              <div className="absolute top-4 right-4 text-pink-200/30 pointer-events-none">
                <Landmark className="w-24 h-24" />
              </div>

              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
                <div>
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-pink-100 text-pink-700 border border-pink-200 shadow-2xs">
                      <Landmark className="w-3.5 h-3.5 text-pink-600" />
                      Linked Demo Bank Account
                    </span>
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-2xs">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      {bankAccount?.status === 'CONNECTED' ? '● Connected' : (bankAccount?.status || '● Connected')}
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    {bankAccount?.bankName || 'FraudGuard Demo Bank'}
                  </h3>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 mt-1 font-mono">
                    <span>Account: <strong className="text-slate-800">{bankAccount?.maskedAccountNumber || 'XXXX XXXX 4521'}</strong></span>
                    <span>&bull;</span>
                    <span>Customer: <strong className="text-slate-800">{currentUser.fullName}</strong></span>
                    <span>&bull;</span>
                    <span>Mobile: <strong className="text-slate-800">{bankAccount?.registeredMobile || currentUser.phone || '+91-98765-01002'}</strong></span>
                  </div>

                  <div className="mt-3.5 flex items-baseline gap-2">
                    <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Available Balance:</span>
                    <span className="text-2xl sm:text-3xl font-black font-mono text-emerald-600">
                      {formatINR(bankAccount?.balance ?? currentUser.balance)}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-500 mt-2 bg-pink-50/60 p-2.5 rounded-xl border border-pink-100/80 max-w-2xl">
                    <Lock className="w-3 h-3 text-pink-500 inline mr-1" />
                    <strong>Safe Simulated Demo Banking:</strong> This is a sandboxed banking demonstration. No real bank passwords, UPI PINs, or card credentials are ever requested or stored.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row lg:flex-col gap-2 shrink-0">
                  <button
                    onClick={() => handleFundDemoAccount(100000)}
                    className="px-4 py-2.5 bg-gradient-to-r from-pink-500 to-rose-500 hover:opacity-95 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <IndianRupee className="w-3.5 h-3.5" />
                    Fund Account (+₹1,00,000)
                  </button>
                  <button
                    onClick={handleResetDemoAccount}
                    className="px-4 py-2 bg-white hover:bg-pink-50 text-slate-700 font-semibold text-xs rounded-xl border border-pink-200 transition cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
                    Reset Balance (₹4,50,000)
                  </button>
                </div>
              </div>
            </div>

            {/* 2. DEMO BANK TRANSACTION SIMULATOR CONTROLS */}
            <div className="bg-white/95 border border-pink-200/80 rounded-3xl p-6 shadow-sm shadow-pink-100/50 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-pink-100 gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-500 text-white flex items-center justify-center shadow-xs">
                    <Radio className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Demo Bank Activity Simulator</h4>
                    <p className="text-xs text-slate-500">
                      Dispatches live transaction events from the demo bank into the real <code className="text-pink-600 font-semibold">FraudDetectionEngine</code>.
                    </p>
                  </div>
                </div>

                {/* Auto-Feed Streaming Toggle Button & Trigger Next Button */}
                <div className="flex items-center gap-2.5 flex-wrap">
                  <button
                    onClick={() => setIsSimulatingFeed(!isSimulatingFeed)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 shadow-xs ${
                      isSimulatingFeed
                        ? 'bg-rose-500 text-white hover:bg-rose-600 ring-2 ring-rose-300'
                        : 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:opacity-95'
                    }`}
                  >
                    {isSimulatingFeed ? (
                      <>
                        <Pause className="w-3.5 h-3.5" />
                        <span className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                          Auto-Feed Streaming (7.5s)
                        </span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" />
                        <span>Start Auto-Feed Mode</span>
                      </>
                    )}
                  </button>

                  <button
                    disabled={simulatingLoading}
                    onClick={() => triggerSimulatedTransaction()}
                    className="px-4 py-2 bg-pink-100/80 hover:bg-pink-200/80 text-pink-800 text-xs font-bold rounded-xl transition border border-pink-200 cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
                  >
                    <Zap className="w-3.5 h-3.5 text-pink-600" />
                    {simulatingLoading ? 'Processing...' : 'Generate Next Bank Transaction'}
                  </button>
                </div>
              </div>

              {/* Preset One-Click Banking Scenario Triggers */}
              <div>
                <span className="text-xs font-bold text-slate-700 block mb-2">
                  Instant One-Click Bank Scenarios (Evaluated via Real FraudDetectionEngine):
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 text-xs">
                  <button
                    disabled={simulatingLoading}
                    onClick={() => triggerSimulatedTransaction('coffee_safe')}
                    className="p-3 rounded-2xl bg-pink-50/30 hover:bg-emerald-50/60 border border-pink-100 hover:border-emerald-200 text-left transition cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between font-bold text-slate-800">
                      <span>☕ Starbucks Cafe</span>
                      <span className="text-[10px] font-mono text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded-full">APPROVED</span>
                    </div>
                    <div className="text-slate-500 text-[11px] font-mono mt-1">Debit: ₹450 &bull; Delhi</div>
                    <div className="text-[10px] text-emerald-700 mt-0.5 font-medium">Clean Purchase &rarr; Score 0</div>
                  </button>

                  <button
                    disabled={simulatingLoading}
                    onClick={() => triggerSimulatedTransaction('amazon_safe')}
                    className="p-3 rounded-2xl bg-pink-50/30 hover:bg-emerald-50/60 border border-pink-100 hover:border-emerald-200 text-left transition cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between font-bold text-slate-800">
                      <span>📦 Amazon India</span>
                      <span className="text-[10px] font-mono text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded-full">APPROVED</span>
                    </div>
                    <div className="text-slate-500 text-[11px] font-mono mt-1">Debit: ₹1,500 &bull; Delhi</div>
                    <div className="text-[10px] text-emerald-700 mt-0.5 font-medium">Deducts ₹1,500 from demo balance</div>
                  </button>

                  <button
                    disabled={simulatingLoading}
                    onClick={() => triggerSimulatedTransaction('grocery_safe')}
                    className="p-3 rounded-2xl bg-pink-50/30 hover:bg-emerald-50/60 border border-pink-100 hover:border-emerald-200 text-left transition cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between font-bold text-slate-800">
                      <span>🛒 Blinkit Grocery</span>
                      <span className="text-[10px] font-mono text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded-full">APPROVED</span>
                    </div>
                    <div className="text-slate-500 text-[11px] font-mono mt-1">Debit: ₹2,850 &bull; Delhi</div>
                    <div className="text-[10px] text-emerald-700 mt-0.5 font-medium">Safe household grocery debit</div>
                  </button>

                  <button
                    disabled={simulatingLoading}
                    onClick={() => triggerSimulatedTransaction('croma_electronics_flagged')}
                    className="p-3 rounded-2xl bg-pink-50/30 hover:bg-rose-50/70 border border-pink-100 hover:border-rose-200 text-left transition cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between font-bold text-slate-800">
                      <span>📱 Croma Tech MegaStore</span>
                      <span className="text-[10px] font-mono text-rose-700 bg-rose-100/80 px-2 py-0.5 rounded-full">FLAGGED</span>
                    </div>
                    <div className="text-slate-500 text-[11px] font-mono mt-1">Debit: ₹75,000 &bull; Mumbai</div>
                    <div className="text-[10px] text-rose-700 mt-0.5 font-medium">Held for review &bull; Funds preserved</div>
                  </button>

                  <button
                    disabled={simulatingLoading}
                    onClick={() => triggerSimulatedTransaction('spike_transfer_flagged')}
                    className="p-3 rounded-2xl bg-pink-50/30 hover:bg-rose-50/70 border border-pink-100 hover:border-rose-200 text-left transition cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between font-bold text-slate-800">
                      <span>⚠️ High Amount Spike</span>
                      <span className="text-[10px] font-mono text-rose-700 bg-rose-100/80 px-2 py-0.5 rounded-full">FLAGGED</span>
                    </div>
                    <div className="text-slate-500 text-[11px] font-mono mt-1">Debit: ₹2,50,000 &bull; Delhi</div>
                    <div className="text-[10px] text-rose-700 mt-0.5 font-medium">Exceeds ₹2,00,000 threshold</div>
                  </button>

                  <button
                    disabled={simulatingLoading}
                    onClick={() => triggerSimulatedTransaction('caracas_blocked')}
                    className="p-3 rounded-2xl bg-pink-50/30 hover:bg-red-50/80 border border-pink-100 hover:border-red-200 text-left transition cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between font-bold text-slate-800">
                      <span>🚨 Overseas Caracas</span>
                      <span className="text-[10px] font-mono text-red-700 bg-red-100/80 px-2 py-0.5 rounded-full">BLOCKED</span>
                    </div>
                    <div className="text-slate-500 text-[11px] font-mono mt-1">Debit: ₹5,00,000 &bull; Caracas</div>
                    <div className="text-[10px] text-red-700 mt-0.5 font-medium">Anomaly Halted &bull; Zero deducted</div>
                  </button>

                  <button
                    disabled={simulatingLoading}
                    onClick={() => triggerSimulatedTransaction('zurich_blocked')}
                    className="p-3 rounded-2xl bg-pink-50/30 hover:bg-red-50/80 border border-pink-100 hover:border-red-200 text-left transition cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between font-bold text-slate-800">
                      <span>🚨 Zurich Swiss Wire</span>
                      <span className="text-[10px] font-mono text-red-700 bg-red-100/80 px-2 py-0.5 rounded-full">BLOCKED</span>
                    </div>
                    <div className="text-slate-500 text-[11px] font-mono mt-1">Debit: ₹10,00,000 &bull; Zurich</div>
                    <div className="text-[10px] text-red-700 mt-0.5 font-medium">High risk surge blocked</div>
                  </button>

                  <button
                    disabled={simulatingLoading}
                    onClick={() => triggerSimulatedTransaction('nocturnal_atm_flagged')}
                    className="p-3 rounded-2xl bg-pink-50/30 hover:bg-purple-50/70 border border-pink-100 hover:border-purple-200 text-left transition cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between font-bold text-slate-800">
                      <span>🌙 Midnight ATM Cash</span>
                      <span className="text-[10px] font-mono text-purple-700 bg-purple-100/80 px-2 py-0.5 rounded-full">FLAGGED</span>
                    </div>
                    <div className="text-slate-500 text-[11px] font-mono mt-1">Debit: ₹1,20,000 &bull; Mumbai</div>
                    <div className="text-[10px] text-purple-700 mt-0.5 font-medium">Off-hours nocturnal cash burst</div>
                  </button>
                </div>
              </div>
            </div>

            {/* 3. LATEST AUTOMATIC CUSTOMER NOTIFICATION BANNER */}
            {lastFeedItem && (
              <div className={`p-4 sm:p-5 rounded-3xl border-2 transition-all duration-300 shadow-sm ${
                lastFeedItem.transaction.status === 'BLOCKED'
                  ? 'bg-red-50 border-red-400 text-red-900 animate-emergency-card'
                  : lastFeedItem.transaction.status === 'FLAGGED'
                  ? 'bg-rose-50 border-rose-300 text-rose-900 animate-emergency-card'
                  : 'bg-emerald-50 border-emerald-300 text-emerald-900'
              }`}>
                <div className="flex items-start gap-3">
                  <div className="shrink-0 mt-0.5">
                    {lastFeedItem.transaction.status === 'BLOCKED' ? (
                      <div className="w-8 h-8 rounded-xl bg-red-600 text-white flex items-center justify-center font-bold">
                        <XCircle className="w-5 h-5" />
                      </div>
                    ) : lastFeedItem.transaction.status === 'FLAGGED' ? (
                      <div className="w-8 h-8 rounded-xl bg-rose-500 text-white flex items-center justify-center font-bold">
                        <AlertTriangle className="w-5 h-5" />
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
                        <CheckCircle className="w-5 h-5" />
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center justify-between gap-1 mb-1">
                      <span className="font-extrabold text-sm tracking-wide">
                        {lastFeedItem.notification.title}
                      </span>
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-white/70 border border-current/30">
                        {lastFeedItem.notification.createdAt}
                      </span>
                    </div>

                    <p className="text-xs font-semibold leading-relaxed">
                      {lastFeedItem.notification.message}
                    </p>

                    <div className="mt-2.5 pt-2 border-t border-current/20 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono">
                      <span>Ref: <strong>{lastFeedItem.transaction.referenceId}</strong></span>
                      <span>Merchant: <strong>{lastFeedItem.transaction.merchant}</strong></span>
                      <span>Action: <strong>{lastFeedItem.notification.recommendedAction}</strong></span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 4. LIVE BANK ACTIVITY (Real-Time Feed from Demo Bank) */}
            <div className="bg-white/95 border border-pink-200/80 rounded-3xl overflow-hidden shadow-sm shadow-pink-100/50">
              <div className="p-4 sm:p-5 border-b border-pink-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-pink-50/30">
                <div>
                  <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                    <Activity className="w-4 h-4 text-pink-600" />
                    Live Bank Activity
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Real-time transaction stream arriving from the simulated bank, evaluated by FraudDetectionEngine.
                  </p>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Auto-Audited Stream</span>
                  <button
                    onClick={loadData}
                    className="p-1.5 hover:bg-pink-100/60 rounded-xl text-slate-600 hover:text-pink-700 transition cursor-pointer"
                    title="Refresh Feed"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-700">
                  <thead className="bg-pink-50/70 uppercase font-semibold text-slate-600 border-b border-pink-100 text-[11px]">
                    <tr>
                      <th className="p-3.5">Time</th>
                      <th className="p-3.5">Amount (₹ INR)</th>
                      <th className="p-3.5">Merchant / Destination</th>
                      <th className="p-3.5">Location</th>
                      <th className="p-3.5">Fraud Engine Status</th>
                      <th className="p-3.5">Risk Rating</th>
                      <th className="p-3.5">Balance Impact</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-pink-100/60 font-medium">
                    {transactions.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="p-6 text-center text-slate-400">
                          No transactions recorded yet in the live bank feed. Click "Generate Next Bank Transaction" above to simulate banking events.
                        </td>
                      </tr>
                    ) : (
                      transactions.slice(0, 15).map(tx => {
                        const timeOnly = tx.createdAt ? tx.createdAt.substring(11, 16) : '--:--';
                        return (
                          <tr key={tx.id} className="hover:bg-pink-50/30 transition">
                            <td className="p-3.5 font-mono text-slate-500 text-[11px] whitespace-nowrap">
                              {timeOnly}
                            </td>
                            <td className="p-3.5 font-mono font-bold text-slate-900 text-sm whitespace-nowrap">
                              Debit {formatINR(tx.amount)}
                            </td>
                            <td className="p-3.5">
                              <div className="font-bold text-slate-800">{tx.merchant || tx.recipientAccount}</div>
                              <div className="text-[10px] text-slate-400 font-mono">{tx.referenceId}</div>
                            </td>
                            <td className="p-3.5 text-slate-600 flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-pink-400 shrink-0" />
                              <span>{tx.location}</span>
                            </td>
                            <td className="p-3.5 whitespace-nowrap">
                              {getStatusBadge(tx.status)}
                            </td>
                            <td className="p-3.5 whitespace-nowrap">
                              {getRiskBadge(tx.riskLevel, tx.riskScore)}
                            </td>
                            <td className="p-3.5 text-[11px] font-mono">
                              {tx.status === 'APPROVED' ? (
                                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                                  <Check className="w-3 h-3 text-emerald-500" />
                                  - {formatINR(tx.amount)} deducted
                                </span>
                              ) : tx.status === 'FLAGGED' ? (
                                <span className="text-amber-700 font-semibold flex items-center gap-1">
                                  <Clock className="w-3 h-3 text-amber-500" />
                                  Hold (Funds protected)
                                </span>
                              ) : (
                                <span className="text-red-700 font-semibold flex items-center gap-1">
                                  <XCircle className="w-3 h-3 text-red-500" />
                                  Blocked (Zero deducted)
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Transaction Ledger (Isolated for Customer, Global for Admin) */}
        {activeTab === 'transactions' && (
          <div className="bg-white/95 border border-pink-200/70 rounded-3xl overflow-hidden shadow-sm shadow-pink-100/50">
            <div className="p-4 sm:p-5 border-b border-pink-100 flex justify-between items-center bg-pink-50/30">
              <div>
                <h3 className="text-sm font-bold text-slate-800">
                  {currentUser.role === 'ADMIN' ? 'System Transaction Ledger' : 'My Personal Transaction Ledger'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {currentUser.role === 'ADMIN' 
                    ? 'Complete multi-user audit trail across all registered accounts (₹ INR).'
                    : `Filtered to transactions executed by ${currentUser.fullName} (${currentUser.accountNumber}).`}
                </p>
              </div>
              <button 
                onClick={loadData} 
                className="p-2 hover:bg-pink-100/60 rounded-xl text-slate-600 hover:text-pink-700 transition cursor-pointer border border-pink-200/60 shadow-xs"
                title="Refresh Ledger"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-pink-50/70 uppercase font-semibold text-slate-600 border-b border-pink-100 text-[11px]">
                  <tr>
                    <th className="p-3.5">Reference</th>
                    {currentUser.role === 'ADMIN' && <th className="p-3.5">User ID</th>}
                    <th className="p-3.5">Accounts Flow</th>
                    <th className="p-3.5">Amount (₹ INR)</th>
                    <th className="p-3.5">Type</th>
                    <th className="p-3.5">Location</th>
                    <th className="p-3.5">Risk Assessment</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-pink-100/60 font-medium">
                  {transactions.length === 0 ? (
                    <tr>
                      <td colSpan={currentUser.role === 'ADMIN' ? 9 : 8} className="p-6 text-center text-slate-400">
                        No transactions found for this account. Use the "Submit Transaction" tab to initiate a transaction.
                      </td>
                    </tr>
                  ) : (
                    transactions.map(tx => (
                      <tr key={tx.id} className="hover:bg-pink-50/40 transition">
                        <td className="p-3.5 font-mono text-pink-700 font-semibold">{tx.referenceId}</td>
                        {currentUser.role === 'ADMIN' && (
                          <td className="p-3.5 font-mono text-slate-500">#{tx.userId}</td>
                        )}
                        <td className="p-3.5">
                          <div className="font-mono text-[11px] text-slate-500">{tx.senderAccount} &rarr;</div>
                          <div className="font-mono text-[11px] text-slate-800 font-semibold">{tx.recipientAccount}</div>
                        </td>
                        <td className="p-3.5 font-bold text-slate-900 font-mono text-sm">{formatINR(tx.amount)}</td>
                        <td className="p-3.5 font-mono text-[11px] text-purple-700 bg-purple-50/60 px-2 py-0.5 rounded-full w-fit my-auto border border-purple-200/60">
                          {tx.transactionType}
                        </td>
                        <td className="p-3.5 text-slate-600">{tx.location}</td>
                        <td className="p-3.5">{getRiskBadge(tx.riskLevel, tx.riskScore)}</td>
                        <td className="p-3.5">{getStatusBadge(tx.status)}</td>
                        <td className="p-3.5 text-slate-400 font-mono text-[11px]">{tx.createdAt}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 3: Submit Transaction */}
        {activeTab === 'submit' && (
          <div className="max-w-xl mx-auto w-full bg-white/95 border border-pink-200/80 rounded-3xl p-7 shadow-lg shadow-pink-100/60 relative overflow-hidden">
            <div className="absolute top-3 right-3 text-pink-200/30 pointer-events-none">
              <Flower2 className="w-16 h-16" />
            </div>

            <div className="flex items-center gap-2.5 mb-2 relative z-10">
              <div className="w-8 h-8 rounded-xl bg-pink-100 flex items-center justify-center text-pink-600 shadow-xs">
                <ArrowUpRight className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                Execute Candidate Transaction
              </h3>
            </div>
            <p className="text-xs text-slate-500 mb-6 leading-relaxed relative z-10">
              Initiates a transaction from <span className="font-semibold text-slate-800">{currentUser.fullName}</span> ({currentUser.accountNumber || 'ACC-ADMIN'}) through the real-time Indian banking <code className="text-purple-600 font-semibold">FraudDetectionEngine</code>.
            </p>

            <form onSubmit={handleTransactionSubmit} className="space-y-4 relative z-10">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Recipient Account</label>
                <input 
                  type="text" 
                  value={recipient}
                  onChange={e => setRecipient(e.target.value)}
                  className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3.5 py-2.5 text-sm text-slate-800 font-mono focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">Amount (₹ INR)</label>
                  <input 
                    type="text" 
                    inputMode="decimal"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    placeholder="e.g. 1500 or 500000 or 1500000000000000000"
                    className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 font-mono font-bold focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">Transaction Type</label>
                  <select 
                    value={txType}
                    onChange={e => setTxType(e.target.value)}
                    className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                  >
                    <option value="PAYMENT">PAYMENT</option>
                    <option value="TRANSFER">TRANSFER</option>
                    <option value="PURCHASE">PURCHASE</option>
                    <option value="WITHDRAWAL">WITHDRAWAL</option>
                    <option value="DEPOSIT">DEPOSIT</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Geographical Origin</label>
                <input 
                  type="text" 
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  placeholder="e.g. New Delhi, India or Caracas, Venezuela"
                  className="w-full bg-pink-50/30 border border-pink-200 rounded-xl px-3.5 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition"
                  required
                />
              </div>

              {/* Verified Fraud Engine Test Scenarios for Demonstration */}
              <div className="bg-pink-50/50 p-4 rounded-2xl border border-pink-200/80 text-[11px] text-slate-600 space-y-2">
                <div className="font-bold text-pink-700 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-pink-500" />
                    Verified Fraud Engine Test Scenarios (Click to Load):
                  </span>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => { setAmount('1500'); setLocation('New Delhi, India'); setTxType('PAYMENT'); }}
                    className="p-2.5 rounded-xl bg-white/90 hover:bg-emerald-50 border border-pink-100 text-left transition cursor-pointer shadow-xs"
                  >
                    <div className="font-bold text-slate-800 flex items-center justify-between">
                      <span>A. Clean Transaction</span>
                      <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">APPROVED</span>
                    </div>
                    <div className="text-slate-500 text-[10px] mt-0.5">₹1,500 in New Delhi &rarr; Score 0</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => { setAmount('500000'); setLocation('New Delhi, India'); setTxType('TRANSFER'); }}
                    className="p-2.5 rounded-xl bg-white/90 hover:bg-rose-50 border border-pink-100 text-left transition cursor-pointer shadow-xs"
                  >
                    <div className="font-bold text-slate-800 flex items-center justify-between">
                      <span>B. High Amount Spike</span>
                      <span className="text-[10px] font-mono font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">FLAGGED</span>
                    </div>
                    <div className="text-slate-500 text-[10px] mt-0.5">₹5,00,000 in New Delhi &rarr; HIGH_AMOUNT</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => { setAmount('50000'); setLocation('Caracas, Venezuela'); setTxType('PAYMENT'); }}
                    className="p-2.5 rounded-xl bg-white/90 hover:bg-rose-50 border border-pink-100 text-left transition cursor-pointer shadow-xs"
                  >
                    <div className="font-bold text-slate-800 flex items-center justify-between">
                      <span>C. Unusual Location</span>
                      <span className="text-[10px] font-mono font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">FLAGGED</span>
                    </div>
                    <div className="text-slate-500 text-[10px] mt-0.5">₹50,000 in Caracas &rarr; Location Mismatch</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => { setAmount('1000000'); setLocation('Caracas, Venezuela'); setTxType('TRANSFER'); }}
                    className="p-2.5 rounded-xl bg-white/90 hover:bg-red-50 border border-pink-100 text-left transition cursor-pointer shadow-xs"
                  >
                    <div className="font-bold text-slate-800 flex items-center justify-between">
                      <span>D. Multi-Factor Critical</span>
                      <span className="text-[10px] font-mono font-bold text-red-700 bg-red-50 px-2 py-0.5 rounded-full border border-red-200">BLOCKED</span>
                    </div>
                    <div className="text-slate-500 text-[10px] mt-0.5">₹10,00,000 in Caracas &rarr; Score &ge; 75 Halted</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => { setAmount('1500000000000000000'); setLocation('New Delhi, India'); setTxType('TRANSFER'); }}
                    className="p-2.5 rounded-xl bg-white/90 hover:bg-purple-50 border border-pink-100 text-left transition cursor-pointer shadow-xs sm:col-span-2"
                  >
                    <div className="font-bold text-slate-800 flex items-center justify-between">
                      <span>E. Large Transaction (₹15 Quintillion INR)</span>
                      <span className="text-[10px] font-mono font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full border border-purple-200">HIGH_AMOUNT</span>
                    </div>
                    <div className="text-slate-500 text-[10px] mt-0.5">₹15,00,00,00,00,00,00,000 in New Delhi &rarr; Evaluated via Real Engine</div>
                  </button>
                </div>
              </div>

              <button 
                type="submit"
                disabled={submittingTx}
                className="w-full bg-gradient-to-r from-pink-500 via-rose-500 to-purple-500 hover:opacity-95 text-white font-semibold py-3 rounded-xl text-sm transition shadow-md shadow-pink-200 disabled:opacity-50 cursor-pointer"
              >
                {submittingTx ? 'Evaluating with Real Rule Engine...' : 'Execute Candidate Transaction'}
              </button>
            </form>

            {/* Submission Feedback Result Card */}
            {submissionFeedback && (
              submissionFeedback.status === 'APPROVED' ? (
                /* APPROVED CLEAN RESULT CARD (Normal serene pink/green aesthetic) */
                <div className="mt-6 p-5 rounded-3xl border-2 border-emerald-300 bg-white/95 shadow-md shadow-emerald-100 space-y-3 relative z-10 transition-all">
                  <div className="flex justify-between items-center pb-2.5 border-b border-emerald-100">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                        <CheckCircle className="w-4 h-4 text-emerald-600" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                          Transaction Approved
                        </h4>
                        <span className="text-[10px] text-emerald-700 font-medium">Passed all fraud rules cleanly</span>
                      </div>
                    </div>
                    {getStatusBadge(submissionFeedback.status)}
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                    <div className="bg-emerald-50/50 p-2.5 rounded-xl border border-emerald-100/80">
                      <span className="text-slate-500 font-bold block text-[10px] mb-0.5">STATUS</span>
                      <span className="text-xs font-black text-emerald-700">APPROVED</span>
                    </div>
                    <div className="bg-emerald-50/50 p-2.5 rounded-xl border border-emerald-100/80">
                      <span className="text-slate-500 font-bold block text-[10px] mb-0.5">RISK SCORE</span>
                      <span className="text-xs font-black font-mono text-emerald-700">{submissionFeedback.riskScore} / 100</span>
                    </div>
                    <div className="bg-emerald-50/50 p-2.5 rounded-xl border border-emerald-100/80">
                      <span className="text-slate-500 font-bold block text-[10px] mb-0.5">RISK LEVEL</span>
                      <span className="text-xs font-black text-emerald-700">{submissionFeedback.riskLevel}</span>
                    </div>
                    <div className="bg-emerald-50/50 p-2.5 rounded-xl border border-emerald-100/80">
                      <span className="text-slate-500 font-bold block text-[10px] mb-0.5">TRANSACTION AMOUNT</span>
                      <span className="text-xs font-black font-mono text-slate-900 truncate" title={formatINR(submissionFeedback.amount)}>
                        {formatINR(submissionFeedback.amount)}
                      </span>
                    </div>
                  </div>

                  <div className="text-xs text-slate-600 font-mono bg-emerald-50/30 p-2.5 rounded-xl border border-emerald-100 flex flex-wrap justify-between gap-1">
                    <span>Ref: <strong className="text-slate-900">{submissionFeedback.referenceId}</strong></span>
                    <span>Recipient: <strong className="text-slate-900">{submissionFeedback.recipientAccount}</strong></span>
                    <span>Origin: <strong className="text-slate-900">{submissionFeedback.location}</strong></span>
                  </div>

                  <div className="text-xs text-emerald-800 bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-200/80 flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Transaction approved. No flashing or alert triggers activated.</span>
                  </div>
                </div>
              ) : (
                /* RISKY RESULT CARD (Full Emergency Mode with Pulse & Coordinated Diagnostics) */
                <div className={`mt-6 p-6 rounded-3xl border-2 transition-all duration-300 relative z-10 ${
                  submissionFeedback.status === 'BLOCKED' || submissionFeedback.riskLevel === 'CRITICAL'
                    ? 'border-red-500 bg-red-50/80 shadow-2xl shadow-red-200 animate-emergency-card'
                    : 'border-rose-400 bg-rose-50/80 shadow-xl shadow-rose-200 animate-emergency-card'
                }`}>
                  {/* Card Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3.5 border-b border-rose-200/80 gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-9 h-9 rounded-2xl flex items-center justify-center text-white shadow-sm animate-emergency-badge ${
                        submissionFeedback.status === 'BLOCKED' ? 'bg-red-600 shadow-red-300' : 'bg-rose-500 shadow-rose-300'
                      }`}>
                        <AlertTriangle className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-slate-900 tracking-wide uppercase flex items-center gap-1.5">
                          <span>🚨 FRAUD ENGINE EVALUATION RESULT</span>
                        </h4>
                        <p className="text-[11px] text-rose-700 font-bold">
                          {submissionFeedback.status === 'BLOCKED'
                            ? 'CRITICAL FRAUD ALERT — TRANSACTION BLOCKED'
                            : 'FRAUD RISK DETECTED — TRANSACTION REQUIRES ATTENTION'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(submissionFeedback.status)}
                    </div>
                  </div>

                  {/* The 4 Core Metric Tiles Requested */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 my-3.5 text-xs">
                    {/* STATUS */}
                    <div className="bg-white/95 p-3 rounded-2xl border border-rose-200 shadow-2xs">
                      <span className="text-slate-500 font-bold block text-[10px] uppercase tracking-wider mb-0.5">STATUS</span>
                      <div className={`text-sm font-black ${
                        submissionFeedback.status === 'BLOCKED' ? 'text-red-700' : 'text-rose-600'
                      }`}>
                        {submissionFeedback.status}
                      </div>
                    </div>

                    {/* RISK SCORE */}
                    <div className="bg-white/95 p-3 rounded-2xl border border-rose-200 shadow-2xs">
                      <span className="text-slate-500 font-bold block text-[10px] uppercase tracking-wider mb-0.5">RISK SCORE</span>
                      <div className="text-sm font-black font-mono text-slate-900 flex items-baseline gap-1">
                        <span className={submissionFeedback.riskScore >= 75 ? 'text-red-600' : 'text-rose-600'}>
                          {submissionFeedback.riskScore}
                        </span>
                        <span className="text-[10px] text-slate-400 font-normal">/ 100</span>
                      </div>
                    </div>

                    {/* RISK LEVEL */}
                    <div className="bg-white/95 p-3 rounded-2xl border border-rose-200 shadow-2xs">
                      <span className="text-slate-500 font-bold block text-[10px] uppercase tracking-wider mb-0.5">RISK LEVEL</span>
                      <div className="mt-0.5">
                        {getRiskBadge(submissionFeedback.riskLevel, submissionFeedback.riskScore)}
                      </div>
                    </div>

                    {/* TRANSACTION AMOUNT */}
                    <div className="bg-white/95 p-3 rounded-2xl border border-rose-200 shadow-2xs">
                      <span className="text-slate-500 font-bold block text-[10px] uppercase tracking-wider mb-0.5">TRANSACTION AMOUNT</span>
                      <div className="text-xs font-black font-mono text-slate-900 truncate" title={formatINR(submissionFeedback.amount)}>
                        {formatINR(submissionFeedback.amount)}
                      </div>
                    </div>
                  </div>

                  {/* Reference details banner */}
                  <div className="text-xs text-slate-700 font-mono bg-white/80 p-2.5 rounded-2xl border border-rose-200/70 flex flex-wrap justify-between gap-1 mb-3">
                    <span>Ref: <strong className="text-slate-900">{submissionFeedback.referenceId}</strong></span>
                    <span>Recipient: <strong className="text-slate-900">{submissionFeedback.recipientAccount}</strong></span>
                    <span>Origin: <strong className="text-slate-900">{submissionFeedback.location}</strong></span>
                  </div>

                  {/* TRIGGERED RULES */}
                  {((submissionFeedback.triggeredRules && submissionFeedback.triggeredRules.length > 0) || 
                    (submissionFeedback.riskAnalysis?.triggeredRules && submissionFeedback.riskAnalysis.triggeredRules.length > 0)) && (
                    <div className="bg-white/95 p-3 rounded-2xl border border-rose-200 shadow-2xs space-y-1.5 mb-3">
                      <span className="text-[11px] font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                        TRIGGERED RULES:
                      </span>
                      <div className="flex flex-wrap gap-1.5 pt-0.5">
                        {(submissionFeedback.triggeredRules || submissionFeedback.riskAnalysis?.triggeredRules || []).map((r: string) => (
                          <span 
                            key={r} 
                            className="font-mono text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-300 shadow-2xs animate-emergency-badge"
                          >
                            {r}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* WHY THIS WAS FLAGGED (Diagnostic Reasons from Real Backend RiskAnalysis) */}
                  {(submissionFeedback.reasons || submissionFeedback.notes) && (
                    <div className="bg-white/95 p-3 rounded-2xl border border-rose-200 shadow-2xs space-y-1.5">
                      <span className="text-[11px] font-black text-slate-800 uppercase tracking-wider block">
                        WHY THIS WAS FLAGGED:
                      </span>
                      {submissionFeedback.reasons && submissionFeedback.reasons.length > 0 ? (
                        <ul className="space-y-1 text-xs text-slate-700">
                          {submissionFeedback.reasons.map((reason: string, i: number) => (
                            <li key={i} className="flex items-start gap-2 font-medium leading-relaxed">
                              <span className="text-rose-500 font-bold mt-0.5">&bull;</span>
                              <span>{reason}</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-xs font-medium text-slate-700 leading-relaxed">{submissionFeedback.notes}</p>
                      )}
                    </div>
                  )}
                </div>
              )
            )}
          </div>
        )}

        {/* Tab 4: Fraud Investigations / Cases */}
        {activeTab === 'cases' && (
          <div className="bg-white/95 border border-pink-200/70 rounded-3xl overflow-hidden shadow-sm shadow-pink-100/50">
            <div className="p-4 sm:p-5 border-b border-pink-100 flex justify-between items-center bg-pink-50/30">
              <div>
                <h3 className="text-sm font-bold text-slate-800">
                  {currentUser.role === 'ADMIN' ? 'Compliance Investigation Cases' : 'My Audit & Investigation Cases'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {currentUser.role === 'ADMIN'
                    ? 'Review, investigate, and resolve transactions flagged by the engine across all Indian accounts.'
                    : 'Cases opened regarding suspicious transactions originating from your account.'}
                </p>
              </div>
              <button 
                onClick={loadData} 
                className="p-2 hover:bg-pink-100/60 rounded-xl text-slate-600 hover:text-pink-700 transition cursor-pointer border border-pink-200/60 shadow-xs"
                title="Refresh Cases"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-pink-50/70 uppercase font-semibold text-slate-600 border-b border-pink-100 text-[11px]">
                  <tr>
                    <th className="p-3.5">Case Number</th>
                    <th className="p-3.5">Tx ID</th>
                    {currentUser.role === 'ADMIN' && <th className="p-3.5">Customer ID</th>}
                    <th className="p-3.5">Risk Score</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">Audit Reason</th>
                    {currentUser.role === 'ADMIN' && <th className="p-3.5">Compliance Action</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-pink-100/60 font-medium">
                  {cases.length === 0 ? (
                    <tr>
                      <td colSpan={currentUser.role === 'ADMIN' ? 7 : 5} className="p-6 text-center text-slate-400">
                        No active investigation cases.
                      </td>
                    </tr>
                  ) : (
                    cases.map(c => (
                      <tr key={c.id} className="hover:bg-pink-50/40 transition">
                        <td className="p-3.5 font-mono text-purple-700 font-semibold">{c.caseNumber}</td>
                        <td className="p-3.5 font-mono">#{c.transactionId}</td>
                        {currentUser.role === 'ADMIN' && <td className="p-3.5 font-mono">#{c.userId}</td>}
                        <td className="p-3.5 font-mono font-bold text-rose-600">{c.riskScore}</td>
                        <td className="p-3.5">
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-purple-50 text-purple-700 border border-purple-200">
                            {c.status}
                          </span>
                        </td>
                        <td className="p-3.5 text-slate-600 max-w-xs truncate">{c.notes}</td>
                        {currentUser.role === 'ADMIN' && (
                          <td className="p-3.5">
                            {c.status !== 'RESOLVED_FRAUD' && c.status !== 'RESOLVED_LEGITIMATE' ? (
                              <div className="flex gap-2">
                                <button 
                                  onClick={() => handleResolveCase(c.id, 'RESOLVED_LEGITIMATE')}
                                  className="px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg border border-emerald-200 text-[11px] font-semibold transition cursor-pointer"
                                >
                                  Approve
                                </button>
                                <button 
                                  onClick={() => handleResolveCase(c.id, 'RESOLVED_FRAUD')}
                                  className="px-2.5 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 rounded-lg border border-rose-200 text-[11px] font-semibold transition cursor-pointer"
                                >
                                  Confirm Fraud
                                </button>
                              </div>
                            ) : (
                              <span className="text-[11px] text-slate-400 italic">Resolved: {c.status}</span>
                            )}
                          </td>
                        )}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 5: Account Profile (All Users) */}
        {activeTab === 'profile' && (
          <div className="max-w-2xl mx-auto w-full bg-white/95 border border-pink-200/80 rounded-3xl p-7 shadow-lg shadow-pink-100/60 relative overflow-hidden">
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-pink-100">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-400 to-purple-400 text-white flex items-center justify-center font-bold text-lg shadow-md shadow-pink-200">
                {currentUser.fullName.charAt(0)}
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">{currentUser.fullName}</h3>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-pink-100 text-pink-700 border border-pink-200/80">
                  Role: {currentUser.role}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-pink-50/40 border border-pink-100">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Username</span>
                <span className="font-mono text-sm font-semibold text-slate-800">{currentUser.username}</span>
              </div>

              <div className="p-4 rounded-2xl bg-pink-50/40 border border-pink-100">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Email Address</span>
                <span className="text-sm font-semibold text-slate-800">{currentUser.email}</span>
              </div>

              {currentUser.role === 'CUSTOMER' && (
                <>
                  <div className="p-4 rounded-2xl bg-pink-50/40 border border-pink-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Linked Demo Bank</span>
                    <span className="font-semibold text-sm text-slate-900">{bankAccount?.bankName || 'FraudGuard Demo Bank'}</span>
                    <span className="text-[11px] text-emerald-700 font-semibold block mt-0.5">● Connected</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-pink-50/40 border border-pink-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Masked Account Number</span>
                    <span className="font-mono text-sm font-bold text-pink-700">{bankAccount?.maskedAccountNumber || currentUser.accountNumber}</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-pink-50/40 border border-pink-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Current Demo Balance</span>
                    <span className="font-mono text-sm font-bold text-emerald-600">
                      {formatINR(bankAccount?.balance ?? currentUser.balance)}
                    </span>
                  </div>

                  <div className="p-4 rounded-2xl bg-pink-50/40 border border-pink-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Registered Mobile (Demo)</span>
                    <span className="font-mono text-sm font-semibold text-slate-800">
                      {bankAccount?.registeredMobile || currentUser.phone || '+91-98765-01002'}
                    </span>
                  </div>

                  <div className="p-4 rounded-2xl bg-pink-50/40 border border-pink-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Risk Profile Rating</span>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                      {currentUser.riskProfile || 'LOW'}
                    </span>
                  </div>
                </>
              )}

              {currentUser.role === 'ADMIN' && (
                <>
                  <div className="p-4 rounded-2xl bg-purple-50/40 border border-purple-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Department</span>
                    <span className="text-sm font-bold text-purple-700">{currentUser.department || 'Security Compliance'}</span>
                  </div>
                  <div className="p-4 rounded-2xl bg-purple-50/40 border border-purple-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Clearance Level</span>
                    <span className="text-sm font-bold text-purple-700">Level {currentUser.clearanceLevel || 3} (Master)</span>
                  </div>
                </>
              )}

              <div className="p-4 rounded-2xl bg-pink-50/40 border border-pink-100">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Account Security</span>
                <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                  SHA-256 Authentication Hash
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 6: User Directory (ADMIN ONLY) */}
        {activeTab === 'users' && currentUser.role === 'ADMIN' && (
          <div className="bg-white/95 border border-pink-200/70 rounded-3xl overflow-hidden shadow-sm shadow-pink-100/50">
            <div className="p-4 sm:p-5 border-b border-pink-100 flex justify-between items-center bg-pink-50/30">
              <div>
                <h3 className="text-sm font-bold text-slate-800">Registered Indian Banking Users</h3>
                <p className="text-xs text-slate-500 mt-0.5">Directory of all active customers and compliance personnel in the database.</p>
              </div>
              <button 
                onClick={loadData} 
                className="p-2 hover:bg-pink-100/60 rounded-xl text-slate-600 hover:text-pink-700 transition cursor-pointer border border-pink-200/60 shadow-xs"
                title="Refresh Users"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-pink-50/70 uppercase font-semibold text-slate-600 border-b border-pink-100 text-[11px]">
                  <tr>
                    <th className="p-3.5">ID</th>
                    <th className="p-3.5">Full Name</th>
                    <th className="p-3.5">Username</th>
                    <th className="p-3.5">Email</th>
                    <th className="p-3.5">Role</th>
                    <th className="p-3.5">Account Number</th>
                    <th className="p-3.5">Balance</th>
                    <th className="p-3.5">Created At</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-pink-100/60 font-medium">
                  {allUsers.map(u => (
                    <tr key={u.id} className="hover:bg-pink-50/40 transition">
                      <td className="p-3.5 font-mono text-slate-500">#{u.id}</td>
                      <td className="p-3.5 font-bold text-slate-900">{u.fullName}</td>
                      <td className="p-3.5 font-mono text-pink-700">{u.username}</td>
                      <td className="p-3.5 text-slate-600">{u.email}</td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          u.role === 'ADMIN' ? 'bg-purple-100 text-purple-700' : 'bg-pink-100 text-pink-700'
                        }`}>
                          {u.role}
                        </span>
                      </td>
                      <td className="p-3.5 font-mono text-slate-700">{u.accountNumber || '—'}</td>
                      <td className="p-3.5 font-mono font-bold text-slate-900">
                        {u.role === 'CUSTOMER' ? formatINR(u.balance) : '—'}
                      </td>
                      <td className="p-3.5 font-mono text-slate-400 text-[11px]">{u.createdAt || 'Initial'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 7: Fraud Rule Configuration (ADMIN ONLY) */}
        {activeTab === 'rules' && currentUser.role === 'ADMIN' && (
          <div className="bg-white/95 border border-pink-200/70 rounded-3xl overflow-hidden shadow-sm shadow-pink-100/50">
            <div className="p-4 sm:p-5 border-b border-pink-100 bg-pink-50/30">
              <h3 className="text-sm font-bold text-slate-800">Detection Engine Rule Configuration</h3>
              <p className="text-xs text-slate-500 mt-1">
                Dynamic weights and threshold boundaries persisted in the <code className="text-pink-600 font-semibold">fraud_rules</code> relational table (Configured in ₹ INR).
              </p>
            </div>
            <div className="divide-y divide-pink-100/80">
              {rules.map(rule => (
                <div key={rule.id} className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-pink-50/20 transition">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-sm text-pink-700 bg-pink-50 px-2.5 py-0.5 rounded-full border border-pink-200">
                        {rule.ruleCode}
                      </span>
                      <span className="text-xs font-bold text-slate-800">&bull; {rule.ruleName}</span>
                    </div>
                    <p className="text-xs text-slate-600 font-medium">{rule.description}</p>
                    <div className="text-[11px] font-mono text-slate-500">
                      Threshold: <span className="text-slate-800 font-semibold">
                        {rule.ruleCode === 'HIGH_AMOUNT' ? formatINR(rule.thresholdValue, false) : rule.thresholdValue}
                      </span> | Weight: <span className="text-rose-600 font-bold">{rule.weight} pts</span>
                    </div>
                  </div>
                  <div>
                    <button
                      onClick={() => toggleRule(rule)}
                      className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition cursor-pointer ${
                        rule.active 
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 shadow-xs' 
                          : 'bg-slate-100 text-slate-500 border border-slate-200 hover:bg-slate-200'
                      }`}
                    >
                      {rule.active ? 'Rule Active' : 'Disabled'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-pink-100/80 py-4 text-center text-xs text-slate-500 bg-white/70 backdrop-blur-xs flex items-center justify-center gap-1.5">
        <span>FraudGuard System</span>
        <span>&bull;</span>
        <span>Enterprise Edition (₹ INR)</span>
        <span>&bull;</span>
        <span>Java 17 + MySQL + Jakarta Servlets</span>
        <Sparkles className="w-3.5 h-3.5 text-pink-400 inline" />
      </footer>
    </div>
  );
}
