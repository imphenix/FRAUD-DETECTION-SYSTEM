# Enterprise Rule-Based Fraud Detection System

A production-grade, full-stack fraud detection and transaction monitoring platform designed for banking and financial compliance. Built with **Java 17**, **Jakarta EE Servlets**, **HikariCP**, **MySQL / MariaDB**, **React 19**, **TypeScript**, and **Tailwind CSS**.

---

## 🌟 Key Features

1. **Multi-Signal Rule-Based Fraud Engine**:
   - `HIGH_AMOUNT`: Detects single transactions breaching dynamic monetary ceilings.
   - `RAPID_TRANSACTIONS`: Sliding-window velocity check leveraging FIFO in-memory time queues.
   - `UNUSUAL_LOCATION`: Anomaly detection contrasting candidate origin against customer historical geographic set.
   - `ODD_HOUR`: Evaluates off-hours transactions during nocturnal windows (01:00 AM – 05:00 AM).
   - `AMOUNT_DEVIATION`: Statistical comparison against customer historical baseline (>300% surge).
   - `REPEATED_FAILURES`: Flags transactions preceded by repeated rejected/failed attempts.
2. **ACID JDBC Transaction Management**:
   - Caller-owned ambient JDBC connection workflow (`setAutoCommit(false)` $\rightarrow$ `commit()` / `rollback()`).
   - Atomic persistence across `transactions`, `fraud_alerts`, and `fraud_cases` tables.
   - Complete zero-partial-state rollback on SQL errors or constraint violations.
3. **High-Throughput Multithreading**:
   - `FraudMonitoringService` with bounded thread pool (`Executors.newFixedThreadPool`).
   - `Callable<TransactionProcessingResult>` and `Future` asynchronous resolution.
   - Synchronized shared state in `FraudStatistics` with verified race-condition immunity.
4. **Compliance Case Management**:
   - Investigation lifecycle: `OPEN` $\rightarrow$ `INVESTIGATING` $\rightarrow$ `RESOLVED_LEGITIMATE` / `RESOLVED_FRAUD`.
   - Security administrator assignment, resolution documentation, and alert auditing.
5. **Interactive Full-Stack Web Application**:
   - Real-time Executive Metrics Dashboard (fraud detection rate, status breakdown, risk distribution).
   - Candidate Transaction Simulator with instant rule breakdown and diagnostic scoring.
   - Transaction Ledger with full audit trails.
   - Fraud Rule Configuration panel with runtime toggle capability.
   - Role-Based Access Control (Admin vs. Customer).

---

## 🏛️ System Architecture

```
 +-----------------------------------------------------------------------------------+
 |                             PRESENTATION / WEB TIER                               |
 |   - Interactive React 19 / Vite Full-Stack UI (Client Dashboard, Submission Form)  |
 |   - Jakarta EE 10 Controller Servlets (AuthServlet, TransactionServlet, etc.)      |
 |   - AuthenticationFilter (Session Guard & RBAC) & JSON Serialization (Gson)       |
 +-----------------------------------------+-----------------------------------------+
                                           |
                                           v
 +-----------------------------------------------------------------------------------+
 |                                   SERVICE TIER                                    |
 |   - TransactionService: End-to-end transaction orchestrator                       |
 |   - FraudDetectionService: Temporal in-memory collection cache & rule bridge      |
 |   - FraudCaseService: Investigation lifecycle management (Open/Assign/Resolve)     |
 |   - UserService: Customer & Admin registration, SHA-256 Auth, Balance management  |
 +-------------------+-------------------------------------+-------------------------+
                     |                                     |
                     v                                     v
 +---------------------------------------+  +---------------------------------------+
 |       FRAUD DETECTION STRATEGY        |  |         CONCURRENCY SERVICE           |
 |  - FraudDetectionEngine               |  |  - FraudMonitoringService             |
 |    * HIGH_AMOUNT Rule                 |  |  - Bounded ThreadPool (ExecutorService)|
 |    * RAPID_TRANSACTIONS (Sliding)     |  |  - TransactionAnalysisTask (Callable) |
 |    * UNUSUAL_LOCATION (Geo Set)       |  |  - Future<TransactionProcessingResult>|
 |    * ODD_HOUR (Nocturnal Window)      |  |  - Thread-Safe FraudStatistics        |
 |    * AMOUNT_DEVIATION (Ledger Mean)   |  +---------------------------------------+
 |    * REPEATED_FAILURES (History)      |
 +-------------------+-------------------+
                     |
                     v
 +-----------------------------------------------------------------------------------+
 |                      JDBC TRANSACTION MANAGEMENT SERVICE                          |
 |   - setAutoCommit(false) -> Atomic Unit of Work -> commit() / rollback()          |
 |   - Caller-Owned Ambient JDBC Connection passing across DAOs                      |
 +-----------------------------------------+-----------------------------------------+
                                           |
                                           v
 +-----------------------------------------------------------------------------------+
 |                             DATA ACCESS OBJECTS (DAO)                             |
 |   - UserDAO, TransactionDAO, FraudCaseDAO, FraudAlertDAO, FraudRuleDAO            |
 |   - Extends AbstractJdbcRepository<T, ID> via RowMapper<T>                        |
 +-----------------------------------------+-----------------------------------------+
                                           |
                                           v
 +-----------------------------------------------------------------------------------+
 |                              DATABASE & CONNECTION                                |
 |   - HikariCP Connection Pool                                                      |
 |   - Primary: MySQL 8 / MariaDB                                                    |
 |   - Fallback: Embedded H2 In-Memory Database (MySQL Mode)                         |
 +-----------------------------------------------------------------------------------+
```

---

## 🚀 Running the Project

### Prerequisites
- **Java**: JDK 17 or higher
- **Node.js**: v18+ and npm
- **Maven**: 3.8+
- **MySQL / MariaDB**: (Optional - embedded zero-config H2 MySQL engine starts automatically if MySQL is offline)

### Commands

1. **Run Full Java Unit & Integration Test Suite (61 tests)**:
   ```bash
   mvn test
   ```

2. **Package Application into WAR**:
   ```bash
   mvn clean package
   ```

3. **Start Standalone Embedded Tomcat Server (Jakarta EE / Java REST API)**:
   ```bash
   mvn exec:java -Dexec.mainClass="com.fraud.Main"
   ```

4. **Start Live Interactive Full-Stack Web Application**:
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser.

---

## 🧪 Comprehensive Test Coverage (61 Tests)

| Phase | Test Class | Focus Area | Tests | Status |
|---|---|---|:---:|:---:|
| **0** | `SmokeTest` | Java & JUnit 5 Runtime | 2 | PASS |
| **1** | `DatabaseConnectionTest` | HikariCP & H2 Fallback | 4 | PASS |
| **2** | `RepositoryTest` | Generic Repository & Mappers | 4 | PASS |
| **3** | `ModelTest` | OOP Domain Entities & SHA-256 | 7 | PASS |
| **4** | `CollectionTest` | Sliding Window & In-Memory Stores | 5 | PASS |
| **5** | `DAOTest` | JDBC CRUD & PreparedStatements | 6 | PASS |
| **6** | `TransactionManagementTest` | ACID Commit & Rollback Semantics | 5 | PASS |
| **7** | `MultithreadingTest` | ExecutorService, Callable, Thread-Safety | 6 | PASS |
| **8** | `FraudDetectionEngineTest` | 6 Multi-Signal Rules & Clamping | 12 | PASS |
| **9** | `ServiceWorkflowTest` | End-to-End Business Services | 6 | PASS |
| **10/12** | `WebLayerTest` | Servlets, Sessions, RBAC Filters | 4 | PASS |
| **TOTAL** | | | **61** | **ALL PASS** |

---

## 👥 Demo User Credentials

- **Customer**:
  - Username: `john_doe`
  - Password: `password123`
  - Balance: `$45,000.00`
  - Account: `ACC-98421001`
- **Security Administrator**:
  - Username: `admin`
  - Password: `admin123`
  - Department: Security Compliance Lead
